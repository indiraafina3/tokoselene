<!DOCTYPE html>
<html lang="en">
<head>
	<title>Detail Transaksi</title>
<?php include 'header.php'; ?>
	<!-- Title Page -->
					<div class="sec-title p-t-10">
									<br><br>
				<h3 class="m-text5 t-center">
					DETAIL TRANSAKSI
				</h3>
			</div>
	
<br>
	<!-- Cart -->
	<section class="cart bgwhite">
		<div class="container">
				<table width="520" cellspacing="1" cellpadding="1">
						<tr>
						<td width="153">Kode Transaksi</td>
						<td width="23"><div align="center" >:</div></td>
						<td width="326">0867868688</td>
						</tr>
						<tr>
						<td>Nama Penerima</td>
						<td><div align="center" >:</div></td>
						<td>Indira Faradiba Afina</td>
						</tr>
						<tr>
						<td>Email Penerima</td>
						<td><div align="center" >:</div></td>
						<td>indira123@gmail.com</td>
						</tr>
						<tr>
						<td>Telepon Penerima</td>
						<td><div align="center" >:</div></td>
						<td>08125628768</td>
						</tr>
						<tr>
						<td>Alamat Penerima</td>
						<td><div align="center" >:</div></td>
						<td >Jln. A. P. Pettarani 3 No. 19 B, Makassar, Indonesia, 90321</td>
						</tr>
						</table>
						<br><br>
			<!-- Cart item -->
			<div class="container-table-cart pos-relative">
				<div class="bgwhite">
					<table class="table-shopping-cart">
						<tr class="table-head">
							<th class="p-l-10">NAMA</th>
							<th class="p-l-10">Harga</th>
							<th class="p-l-10">Jumlah</th>
							<th class="p-l-10">Total</th>
						</tr>

						<tr class="table-row">
							<td class="p-l-10">Produk</td>
							<td class="p-l-10">Rp 10.000</td>
							<td class="p-l-10">1</td>
							<td class="p-l-10">Rp 10.000</td>
						</tr>
					</table>
				</div>
			</div>

			<br>
						<div class="col-md-6 p-b-30">
						<span class="s-text18 w-size19 w-full-sm">
						Subtotal : Rp 10.000
						</span>
						<br><br>
								<!-- Button -->
							<div class="row">
							<button class="flex-c-m size2 m-text3 w-size25" style="color: white; background-color: red; margin-left : auto;">
								Batal
							</button>

							<button class="flex-c-m size2 bg1 m-text3 w-size25" style="margin-left : 10px;">
								Checkout
							</button>
						</div>		
				</div>
		</div>
	</section>


	<!-- Footer -->
	<footer class="bg6 p-t-45 p-b-43 p-l-45 p-r-45">
		<div class="flex-w p-b-90">
			<div class="w-size6 p-t-30 p-l-15 p-r-15 respon3">
				<h4 class="s-text12 p-b-30">
					GET IN TOUCH
				</h4>

				<div>
					<p class="s-text7 w-size26">
						Ada pertanyaan? Beritahu kami di toko di Pettarani 3, Makassar, Sulawesi Selatan. 08123489990
					</p>

					<div class="flex-m p-t-30">
						<a href="#" class="fs-18 color1 p-r-20 fa fa-facebook"></a>
						<a href="#" class="fs-18 color1 p-r-20 fa fa-instagram"></a>
					</div>
				</div>
			</div>

			<div class="w-size6 p-t-30 p-l-15 p-r-15 respon3">
				<h4 class="s-text12 p-b-30">
					TENTANG
				</h4>

				<div>
					<p class="s-text7 w-size23">
						Selene's shop didirikan pada tahun 2019 sebuah toko kerajinan tangan yang berada di jalan Pettarani 3, Makassar, Indonesia. Berfokus pada berbagai kerajinan tangan dan kini masih berusaha untuk memperluas marketnya di daerah makassar. 
					</p>

				</div>
			</div>


			<div class="w-size7 p-t-30 p-l-15 p-r-15 respon4">
				<h4 class="s-text12 p-b-30">
					Menu
				</h4>

				<ul>
					<li class="p-b-9">
						<a href="#" class="s-text7">
							Katalog
						</a>
					</li>

					<li class="p-b-9">
						<a href="#" class="s-text7">
							Checkout
						</a>
					</li>
				</ul>
			</div>

			<div class="w-size7 p-t-30 p-l-15 p-r-15 respon4">
				<h4 class="s-text12 p-b-30">
					Help
				</h4>

				<ul>
					<li class="p-b-9">
						<a href="#" class="s-text7">
							About
						</a>
					</li>

					<li class="p-b-9">
						<a href="#" class="s-text7">
							Contact
						</a>
					</li>
				</ul>
			</div>

		</div>

		<div class="t-center p-l-15 p-r-15">
			<div class="t-center s-text8 p-t-20">
				Copyright © 2019 All rights reserved. <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://indibaaa.carrd.co" target="_blank">indira</a>
			</div>
		</div>
	</footer>






	<!-- Back to top -->
	<div class="btn-back-to-top bg0-hov" id="myBtn">
		<span class="symbol-btn-back-to-top">
			<i class="fa fa-angle-double-up" aria-hidden="true"></i>
		</span>
	</div>

	<!-- Container Selection -->
	<div id="dropDownSelect1"></div>
	<div id="dropDownSelect2"></div>



<!--===============================================================================================-->
	<script type="text/javascript" src="<?php echo base_url()."/assets/";?>vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="<?php echo base_url()."/assets/";?>vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="<?php echo base_url()."/assets/";?>vendor/bootstrap/js/popper.js"></script>
	<script type="text/javascript" src="<?php echo base_url()."/assets/";?>vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="<?php echo base_url()."/assets/";?>vendor/select2/select2.min.js"></script>
	<script type="text/javascript">
		$(".selection-1").select2({
			minimumResultsForSearch: 20,
			dropdownParent: $('#dropDownSelect1')
		});

		$(".selection-2").select2({
			minimumResultsForSearch: 20,
			dropdownParent: $('#dropDownSelect2')
		});
	</script>
<!--===============================================================================================-->
	<script src="<?php echo base_url()."/assets/";?>js/main.js"></script>

</body>
</html>
