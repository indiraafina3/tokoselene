<!DOCTYPE html>
<html lang="en">
<head>
	<title>Pengiriman</title>
<?php include 'header.php'; ?>
	<!-- Title Page -->
					<div class="sec-title p-t-10">
					<br><br>
				<h3 class="m-text5 t-center">
					PENGIRIMAN
				</h3>
			</div>
	<br>

	<!-- Cart -->
	<section class="cart bgwhite">
		<div class="container">
			<!-- Cart item -->
			<div class="container-table-cart pos-relative">
				<div class="wrap-table-shopping-cart bgwhite">
					<table class="table-shopping-cart">
						<tr class="table-head">
							<th class="column-1">GAMBAR</th>
							<th class="column-2">CART</th>
							<th class="column-3">Harga</th>
							<th class="column-4 p-l-70">Jumlah</th>
							<th class="column-5">Total</th>
						</tr>

						<tr class="table-row">
							<td class="column-1">
								<div class="wrap-pic-w">
									<img src="<?php echo base_url()."/assets/";?>images/gallery-15.jpg" alt="IMG-PRODUCT">
								</div>
							</td>
							<td class="column-2">Produk</td>
							<td class="column-3">Rp 10.000</td>
							<td class="column-4">
								<div class="flex-w bo5 of-hidden w-size17" style="margin-left: 50px;">
									<button class="btn-num-product-down color1 flex-c-m size7 bg8 eff2">
										<i class="fs-12 fa fa-minus" aria-hidden="true"></i>
									</button>

									<input class="size8 m-text18 t-center num-product" type="number" name="num-product1" value="1">

									<button class="btn-num-product-up color1 flex-c-m size7 bg8 eff2">
										<i class="fs-12 fa fa-plus" aria-hidden="true"></i>
									</button>
								</div>
							</td>
							<td class="column-5">Rp 10.000</td>
						</tr>
					</table>
				</div>
			</div>

			<br>
						<div class="col-md-6 p-b-30">
					<form class="leave-comment">
						<span class="s-text18 w-size19 w-full-sm">
						Subtotal : Rp 10.000
					</span>
					<br><br>
						<span>Kode Transaksi</span>

						<div class="bo4 of-hidden size15 m-b-20">
							<input class="sizefull s-text7 p-l-22 p-r-22" type="text" name="name" placeholder="0867868688">
						</div>
						<span>Nama Penerima</span>
						<div class="bo4 of-hidden size15 m-b-20">
							<input class="sizefull s-text7 p-l-22 p-r-22" type="text" name="phone-number" placeholder="Indira Faradiba Afina">
						</div>
						<span>Email Penerima</span>
						<div class="bo4 of-hidden size15 m-b-20">
							<input class="sizefull s-text7 p-l-22 p-r-22" type="text" name="email" placeholder="indira123@gmail.com">
						</div>
						<span>Telepon Penerima</span>
						<div class="bo4 of-hidden size15 m-b-20">
							<input class="sizefull s-text7 p-l-22 p-r-22" type="text" name="email" placeholder="081275746545">
						</div>
												<span>Alamat Penerima</span>
												<div class="rs2-select2 rs3-select2 rs4-select2 bo4 of-hidden w-size21 m-t-8 m-b-12">
							<select class="selection-1" name="negara">
								<option>Pilih Negara</option>
								<option>Indonesia</option>
							</select>

						</div>
						
						<div class="rs2-select2 rs3-select2 rs4-select2 bo4 of-hidden w-size21 m-t-8 m-b-12">
								<select class="selection-2" name="kota">
								<option>Pilih Kota</option>
								<option>Makassar</option>
							</select>
						</div>
							<div class="size13 bo4 m-b-12">
						<input class="sizefull s-text7 p-l-15 p-r-15" type="text" name="state" placeholder="Kode Pos">
						</div>
						<div class="bo4 of-hidden size15 m-b-20">
						<input class="sizefull s-text7 p-l-15 p-r-15" type="text" name="state" placeholder="Alamat">
						</div>
						</form>
								<!-- Button -->
							<div class="row">
							<button class="flex-c-m size2 m-text3 w-size25" style="color: white; background-color: red; margin-left : auto;">
								Batal
							</button>

							<button class="flex-c-m size2 bg1 m-text3 w-size25" style="margin-left : 10px;">
								Checkout
							</button>
						</div>		
				</div>
		</div>
	</section>



	<!-- Footer -->
	<footer class="bg6 p-t-45 p-b-43 p-l-45 p-r-45">
		<div class="flex-w p-b-90">
			<div class="w-size6 p-t-30 p-l-15 p-r-15 respon3">
				<h4 class="s-text12 p-b-30">
					GET IN TOUCH
				</h4>

				<div>
					<p class="s-text7 w-size26">
						Ada pertanyaan? Beritahu kami di toko di Pettarani 3, Makassar, Sulawesi Selatan. 08123489990
					</p>

					<div class="flex-m p-t-30">
						<a href="#" class="fs-18 color1 p-r-20 fa fa-facebook"></a>
						<a href="#" class="fs-18 color1 p-r-20 fa fa-instagram"></a>
					</div>
				</div>
			</div>

			<div class="w-size6 p-t-30 p-l-15 p-r-15 respon3">
				<h4 class="s-text12 p-b-30">
					TENTANG
				</h4>

				<div>
					<p class="s-text7 w-size23">
						Selene's shop didirikan pada tahun 2019 sebuah toko kerajinan tangan yang berada di jalan Pettarani 3, Makassar, Indonesia. Berfokus pada berbagai kerajinan tangan dan kini masih berusaha untuk memperluas marketnya di daerah makassar. 
					</p>

				</div>
			</div>


			<div class="w-size7 p-t-30 p-l-15 p-r-15 respon4">
				<h4 class="s-text12 p-b-30">
					Menu
				</h4>

				<ul>
					<li class="p-b-9">
						<a href="#" class="s-text7">
							Katalog
						</a>
					</li>

					<li class="p-b-9">
						<a href="#" class="s-text7">
							Checkout
						</a>
					</li>
				</ul>
			</div>

			<div class="w-size7 p-t-30 p-l-15 p-r-15 respon4">
				<h4 class="s-text12 p-b-30">
					Help
				</h4>

				<ul>
					<li class="p-b-9">
						<a href="#" class="s-text7">
							About
						</a>
					</li>

					<li class="p-b-9">
						<a href="#" class="s-text7">
							Contact
						</a>
					</li>
				</ul>
			</div>

		</div>

		<div class="t-center p-l-15 p-r-15">
			<div class="t-center s-text8 p-t-20">
				Copyright © 2019 All rights reserved. <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://indibaaa.carrd.co" target="_blank">indira</a>
			</div>
		</div>
	</footer>






	<!-- Back to top -->
	<div class="btn-back-to-top bg0-hov" id="myBtn">
		<span class="symbol-btn-back-to-top">
			<i class="fa fa-angle-double-up" aria-hidden="true"></i>
		</span>
	</div>

	<!-- Container Selection -->
	<div id="dropDownSelect1"></div>
	<div id="dropDownSelect2"></div>



<!--===============================================================================================-->
	<script type="text/javascript" src="<?php echo base_url()."/assets/";?>vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="<?php echo base_url()."/assets/";?>vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="<?php echo base_url()."/assets/";?>vendor/bootstrap/js/popper.js"></script>
	<script type="text/javascript" src="<?php echo base_url()."/assets/";?>vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="<?php echo base_url()."/assets/";?>vendor/select2/select2.min.js"></script>
	<script type="text/javascript">
		$(".selection-1").select2({
			minimumResultsForSearch: 20,
			dropdownParent: $('#dropDownSelect1')
		});

		$(".selection-2").select2({
			minimumResultsForSearch: 20,
			dropdownParent: $('#dropDownSelect2')
		});
	</script>
<!--===============================================================================================-->
	<script src="<?php echo base_url()."/assets/";?>js/main.js"></script>

</body>
</html>
