<!DOCTYPE html>
<html lang="en">
<head>
	<title>Profile</title>
<?php include 'header.php'; ?>
	<!-- Title Page -->
					<div class="sec-title p-t-10">
									<br><br>
				<h3 class="m-text5 t-center">
					PROFILE
				</h3>
			</div>
	
<br>
	<!-- Cart -->
	<section class="container bgwhite">
		<br>			
						<span>Nama Penerima</span>
						<div class="bo4 of-hidden size15 m-b-20">
							<input class="sizefull s-text7 p-l-22 p-r-22" type="text" name="nama" value="<?php echo $detail->nama;?>" disabled>
						</div>
						<span>Email Penerima</span>
						<div class="bo4 of-hidden size15 m-b-20">
							<input class="sizefull s-text7 p-l-22 p-r-22" type="email" name="email" value="<?php echo $detail->email;?>" disabled>
						</div>
						<span>Telepon Penerima</span>
						<div class="bo4 of-hidden size15 m-b-20">
							<input class="sizefull s-text7 p-l-22 p-r-22" type="tel" name="telepon" value="<?php echo $detail->telepon;?>" disabled>
						</div>
						<span>Alamat Penerima</span>
						<div class="bo4 of-hidden size15 m-b-20">
						<input class="sizefull s-text7 p-l-15 p-r-15" type="text" name="alamat" value="<?php echo $detail->alamat;?>" disabled>
						</div>
						<span>Password</span>
						<div class="bo4 of-hidden size15 m-b-20">
						<input class="sizefull s-text7 p-l-15 p-r-15" type="Password" name="password" value="<?php echo $detail->password;?>" disabled>
						</div>
								<!-- Button -->
							<div class="row" style="float: right;">
							<a class="button flex-c-m size2 bg1 m-text3 w-size25" style="margin-left : 10px; color: white;" href="<?php echo base_url()."Akun/edit";?>">EDIT</a>
						</div>
						<br><br><br>	
	</section>



	<!-- Footer -->
	<footer class="bg6 p-t-45 p-b-43 p-l-45 p-r-45">
		<div class="flex-w p-b-90">
			<div class="w-size6 p-t-30 p-l-15 p-r-15 respon3">
				<h4 class="s-text12 p-b-30">
					GET IN TOUCH
				</h4>

				<div>
					<p class="s-text7 w-size26">
						Ada pertanyaan? Beritahu kami di toko di Pettarani 3, Makassar, Sulawesi Selatan. 08123489990
					</p>

					<div class="flex-m p-t-30">
						<a href="#" class="fs-18 color1 p-r-20 fa fa-facebook"></a>
						<a href="#" class="fs-18 color1 p-r-20 fa fa-instagram"></a>
					</div>
				</div>
			</div>

			<div class="w-size6 p-t-30 p-l-15 p-r-15 respon3">
				<h4 class="s-text12 p-b-30">
					TENTANG
				</h4>

				<div>
					<p class="s-text7 w-size23">
						Selene's shop didirikan pada tahun 2019 sebuah toko kerajinan tangan yang berada di jalan Pettarani 3, Makassar, Indonesia. Berfokus pada berbagai kerajinan tangan dan kini masih berusaha untuk memperluas marketnya di daerah makassar. 
					</p>

				</div>
			</div>


			<div class="w-size7 p-t-30 p-l-15 p-r-15 respon4">
				<h4 class="s-text12 p-b-30">
					Menu
				</h4>

				<ul>
					<li class="p-b-9">
						<a href="#" class="s-text7">
							Katalog
						</a>
					</li>

					<li class="p-b-9">
						<a href="#" class="s-text7">
							Checkout
						</a>
					</li>
				</ul>
			</div>

			<div class="w-size7 p-t-30 p-l-15 p-r-15 respon4">
				<h4 class="s-text12 p-b-30">
					Help
				</h4>

				<ul>
					<li class="p-b-9">
						<a href="#" class="s-text7">
							About
						</a>
					</li>

					<li class="p-b-9">
						<a href="#" class="s-text7">
							Contact
						</a>
					</li>
				</ul>
			</div>

		</div>

		<div class="t-center p-l-15 p-r-15">
			<div class="t-center s-text8 p-t-20">
				Copyright © 2019 All rights reserved. <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://indibaaa.carrd.co" target="_blank">indira</a>
			</div>
		</div>
	</footer>






	<!-- Back to top -->
	<div class="btn-back-to-top bg0-hov" id="myBtn">
		<span class="symbol-btn-back-to-top">
			<i class="fa fa-angle-double-up" aria-hidden="true"></i>
		</span>
	</div>

	<!-- Container Selection -->
	<div id="dropDownSelect1"></div>
	<div id="dropDownSelect2"></div>



<!--===============================================================================================-->
	<script type="text/javascript" src="<?php echo base_url()."/assets/";?>vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="<?php echo base_url()."/assets/";?>vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="<?php echo base_url()."/assets/";?>vendor/bootstrap/js/popper.js"></script>
	<script type="text/javascript" src="<?php echo base_url()."/assets/";?>vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="<?php echo base_url()."/assets/";?>vendor/select2/select2.min.js"></script>
	<script type="text/javascript">
		$(".selection-1").select2({
			minimumResultsForSearch: 20,
			dropdownParent: $('#dropDownSelect1')
		});

		$(".selection-2").select2({
			minimumResultsForSearch: 20,
			dropdownParent: $('#dropDownSelect2')
		});
	</script>
<!--===============================================================================================-->
	<script src="<?php echo base_url()."/assets/";?>js/main.js"></script>

</body>
</html>
