<!DOCTYPE html>
<html lang="en">
<head>
	<title>Katalog</title>
<?php include 'header.php'; ?>
	<!-- Judul -->
	<section class="newproduct bgwhite p-t-45 p-b-105">
		<div class="container">
			<div class="sec-title p-b-60">
				<h3 class="m-text5 t-center">
					KATALOG
				</h3>
			</div>

			<!-- Product -->

			<div class="row">
				
			<?php foreach ($produk as $prd) : ?>
				<div class="col-sm-12 col-md-6 col-lg-4 p-b-50">
					<form method="POST" action="<?php echo base_url().'Produk/add_cart'; ?>">
					<input type="hidden" name="name" value="<?php echo $prd->nama_produk; ?>" >
       				<input type="hidden" name="qty" value="1">
       				<input type="hidden" name="price" value="<?php echo $prd->harga; ?>">
       				<input type="hidden"  name="id"  value="<?php echo $prd->id_produk; ?>">
       				<input type="hidden"  name="image"  value="<?php echo base_url().'uploads/'.$prd->gambar1; ?>">
						<!-- Block2 -->
						<div class="block2">

							<div class="block2-img wrap-pic-w of-hidden pos-relative">
								<img src="<?php echo base_url().'uploads/'.$prd->gambar1?>" alt="IMG-PRODUCT">

								<div class="block2-overlay trans-0-4">

									<div class="block2-btn-addcart w-size1 trans-0-4">
										<!-- Button -->
										<button class="flex-c-m size1 bg4 bo-rad-23 hov1 s-text1 trans-0-4" type="submit" >Add to Cart</button>
									</div>
								</div>
							</div>

							<div class="block2-txt p-t-20">
								<a href="<?php echo base_url().'Produk/detail/'.$prd->id_produk;?>" class="block2-name dis-block s-text3 p-b-5">
												<?php echo $prd->nama_produk; ?>
								</a>

								<span class="block2-price m-text6 p-r-5">
									Rp. <?php echo number_format($prd->harga,'0',',','.'); ?>
								</span>
							</div>
						</div>
					</form>
					</div>
			<?php endforeach; ?>
				</div>
	</section>


	<!-- Footer -->
	<footer class="bg6 p-t-45 p-b-43 p-l-45 p-r-45">
		<div class="flex-w p-b-90">
			<div class="w-size6 p-t-30 p-l-15 p-r-15 respon3">
				<h4 class="s-text12 p-b-30">
					GET IN TOUCH
				</h4>

				<div>
					<p class="s-text7 w-size26">
						Ada pertanyaan? Beritahu kami di toko di Pettarani 3, Makassar, Sulawesi Selatan. 08123489990
					</p>

					<div class="flex-m p-t-30">
						<a href="#" class="fs-18 color1 p-r-20 fa fa-facebook"></a>
						<a href="#" class="fs-18 color1 p-r-20 fa fa-instagram"></a>
					</div>
				</div>
			</div>

			<div class="w-size6 p-t-30 p-l-15 p-r-15 respon3">
				<h4 class="s-text12 p-b-30">
					TENTANG
				</h4>

				<div>
					<p class="s-text7 w-size23">
						Selene's shop didirikan pada tahun 2019 sebuah toko kerajinan tangan yang berada di jalan Pettarani 3, Makassar, Indonesia. Berfokus pada berbagai kerajinan tangan dan kini masih berusaha untuk memperluas marketnya di daerah makassar. 
					</p>

				</div>
			</div>


			<div class="w-size7 p-t-30 p-l-15 p-r-15 respon4">
				<h4 class="s-text12 p-b-30">
					Menu
				</h4>

				<ul>
					<li class="p-b-9">
						<a href="<?php echo base_url()."Produk/katalog";?>" class="s-text7">
							Katalog
						</a>
					</li>

					<li class="p-b-9">
						<a href="<?php echo base_url()."Transaksi/checkout";?>" class="s-text7">
							Checkout
						</a>
					</li>
				</ul>
			</div>


		</div>

		<div class="t-center p-l-15 p-r-15">
			<div class="t-center s-text8 p-t-20">
				Copyright © 2019 All rights reserved. <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://indibaaa.carrd.co" target="_blank">indira</a>
			</div>
		</div>
	</footer>



	<!-- Back to top -->
	<div class="btn-back-to-top bg0-hov" id="myBtn">
		<span class="symbol-btn-back-to-top">
			<i class="fa fa-angle-double-up" aria-hidden="true"></i>
		</span>
	</div>

	<!-- Container Selection1 -->
	<div id="dropDownSelect1"></div>



<!--===============================================================================================-->
	<script type="text/javascript" src="<?php echo base_url()."/assets/";?>vendor/jquery/jquery-3.2.1.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="<?php echo base_url()."/assets/";?>vendor/animsition/js/animsition.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="<?php echo base_url()."/assets/";?>vendor/bootstrap/js/popper.js"></script>
	<script type="text/javascript" src="<?php echo base_url()."/assets/";?>vendor/bootstrap/js/bootstrap.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="<?php echo base_url()."/assets/";?>vendor/select2/select2.min.js"></script>
	<script type="text/javascript">
		$(".selection-1").select2({
			minimumResultsForSearch: 20,
			dropdownParent: $('#dropDownSelect1')
		});
	</script>
<!--===============================================================================================-->
	<script type="text/javascript" src="<?php echo base_url()."/assets/";?>vendor/slick/slick.min.js"></script>
	<script type="text/javascript" src="<?php echo base_url()."/assets/";?>js/slick-custom.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="<?php echo base_url()."/assets/";?>vendor/countdowntime/countdowntime.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="<?php echo base_url()."/assets/";?>vendor/lightbox2/js/lightbox.min.js"></script>
<!--===============================================================================================-->
	<script type="text/javascript" src="<?php echo base_url()."/assets/";?>vendor/sweetalert/sweetalert.min.js"></script>
	<script type="text/javascript">
	
	</script>

<!--===============================================================================================-->
	<script src="<?php echo base_url()."/assets/";?>js/main.js"></script>

</body>
</html>
