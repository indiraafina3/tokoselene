<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Transaksi extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function checkout()
	{
		$id_user = $this->session->userdata('id_user'); 
		$data['detail']=$this->model_akun->get_detail($id_user);
		$this->load->view('Transaksi/checkout',$data);
	}
	public function detail_checkout($id_user)
	{
		$data['detail']=$this->model_akun->get_detail($id_user);
		$this->load->view('Transaksi/checkout',$data);
	}

	public function lihat()
	{
		$this->load->view('Transaksi/transaksi');
	}
	public function detail()
	{
		$this->load->view('Transaksi/detailtransaksi');
	}
	public function pembayaran()
	{
		$this->load->view('Transaksi/pembayaran');
	}
	public function statuskirim()
	{
		$this->load->view('Transaksi/pengiriman');
	}
	public function cetaktransaksi()
	{
		$this->load->view('Transaksi/cetaktransaksi');
	}
}
