<?php 

/**
 * 
 */
class Model_akun extends CI_Model
{

	public function register_akun($data, $table){
		
		 $this->db->insert($table,$data);
	}
	public function get_detail($id_user){
		
		return $this->db->get_where('user', array('id_user' => $id_user))->row();
	}
	function can_login ($post)
	{
		$this->db->select('*');
		$this->db->from('user');
		$this->db->where('email', $post['email']);
		$this->db->where('password', $post['password']);
		$query = $this->db->get();
		return $query;
		}
}
